# Legal Chain of Thought Reasoning

This module implements a 4-step logic flow for analyzing legal scenarios using structured inference: Issue, Rule, Application, Conclusion (IRAC).
